// Include necessary headers
#include "CreatureScript.h"
#include "PetDefines.h"
#include "Player.h"
#include "SpellAuraEffects.h"
#include "SpellInfo.h"
#include "SpellMgr.h"
#include "SpellScript.h"
#include "SpellScriptLoader.h"
#include "Totem.h"
#include "UnitAI.h"
#include "CellImpl.h"
#include <GridNotifiers.h>

#define SPELL_ROGUE_KICK 1766
#define SPELL_DEATH_GRIP 49560
#define SPELL_DEATH_GRIP_MOVE 57604 // Assuming 57604 is the spell ID for the Death Grip pull effect

class spell_dk_death_grasp : public SpellScriptLoader
{
public:
    spell_dk_death_grasp() : SpellScriptLoader("spell_dk_death_grasp") { }

    class spell_dk_death_grasp_SpellScript : public SpellScript
    {
        PrepareSpellScript(spell_dk_death_grasp_SpellScript);

        SpellCastResult CheckCast()
        {
            Unit* caster = GetCaster();
            if (caster->HasUnitState(UNIT_STATE_JUMPING) || caster->HasUnitMovementFlag(MOVEMENTFLAG_FALLING))
                return SPELL_FAILED_MOVING;

            return SPELL_CAST_OK;
        }

        void HandleDummy(SpellEffIndex /*effIndex*/)
        {
            Unit* caster = GetCaster();
            if (!caster)
                return;

            float range = 30.0f;
            std::list<Unit*> targets;
            Acore::AnyUnfriendlyUnitInObjectRangeCheck u_check(caster, caster, range);
            Acore::UnitListSearcher<Acore::AnyUnfriendlyUnitInObjectRangeCheck> searcher(caster, targets, u_check);
            Cell::VisitAllObjects(caster, searcher, range);

            for (Unit* target : targets)
            {
                if (target && target != caster)
                {
                    // Interrupt non-melee spells
                    SpellInfo const* spellInfo = sSpellMgr->GetSpellInfo(SPELL_ROGUE_KICK);
                    if (spellInfo && !target->IsImmunedToSpellEffect(spellInfo, EFFECT_0))
                        target->InterruptNonMeleeSpells(false, 0, false);

                    // Move target to caster's position
                    target->CastSpell(caster->GetPositionX(), caster->GetPositionY(), caster->GetPositionZ(), SPELL_DEATH_GRIP_MOVE, true);
                }
            }
        }

        void Register() override
        {
            OnCheckCast += SpellCheckCastFn(spell_dk_death_grasp_SpellScript::CheckCast);
            OnEffectHitTarget += SpellEffectFn(spell_dk_death_grasp_SpellScript::HandleDummy, EFFECT_0, SPELL_EFFECT_DUMMY);
        }
    };

    SpellScript* GetSpellScript() const override
    {
        return new spell_dk_death_grasp_SpellScript();
    }
};

void AddSC_spell_dk_death_grasp()
{
    new spell_dk_death_grasp();
}
